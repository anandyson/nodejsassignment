var lin;
var fs = require('fs'),
   readline = require('readline');

var rd = readline.createInterface({
   input: fs.createReadStream('Indicators.csv'),
   output: process.stdout,
   terminal: false
});
var countryName=["Afghanistan","Armenia","Azerbaijan","Bahrain","Bangladesh","Bhutan","Brunei Darussalam","Cambodia","China","India","Indonesia","Iran, Islamic Rep.","Iraq","Israel","Palestine","Japan","Jordan","Kazakhstan","Kuwait","Lebanon","Malaysia","Maldives","Mongolia","Myanmar","Nepal","Oman","Pakistan","Philippines","Qatar","Russian Federation","Saudi Arabia","Singapore","Sri Lanka","Syrian Arab Republic","Tajikistan","Thailand","Turkey","Turkmenistan","United Arab Emirates","Uzbekistan","Vietnam","Yemen, Rep."];
var i=0,k=new Array(),initial=1;
for(i=1960;i<2015;i++)
{
    k[i]=0;
}
var obj1=[];
var header=[];
rd.on('line', function(line) {
        lin=line;
       check=lin.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);

       if(initial==1)
       {
           header=check;
           initial=0;
       }
        if(countryName.indexOf(check[0])!=-1)
        {

            //  console.log(check);
            if ((check[2]=='"Life expectancy at birth, female (years)"')||( check[2]=='"Life expectancy at birth, male (years)"'))
            {
                if(k[(parseFloat(check[4]))]!=0)

                {
                    for(i=0;i<obj1.length;i++)
                    {
                        if(obj1[i].year==check[4])
                        {
                            if(check[2]==='"Life expectancy at birth, female (years)"')
                            {
                                obj1[i].lifefemale = obj1[i].lifefemale+(parseFloat(check[5]));
                                    // console.log(obj1[i].lifefemale);
                                    }
                            else if(check[2]==='"Life expectancy at birth, male (years)"')
                            {
                                obj1[i].lifemale = obj1[i].lifemale +(parseFloat(check[5]));
                                    // console.log(obj1[i].lifemale);


                            }
                        }
                    }
                }
                else if((k[(parseFloat(check[4]))]==0))
                {
                    obj1[obj1.length] = new Object();
                    obj1[obj1.length-1].lifemale=0;
                    obj1[obj1.length-1].lifefemale=0;
                    obj1[obj1.length-1].year=check[4];

                    if(check[2]=='"Life expectancy at birth, female (years)"')
                    {
                        obj1[obj1.length-1].lifefemale+= (parseFloat(check[5]));
                        // console.log((+(obj1[obj1.length-1].lifefemale)));
                    }
                    else if(check[2]=='"Life expectancy at birth, male (years)"')
                    {
                        obj1[obj1.length-1].lifemale+= (parseFloat(check[5]));
                        // console.log((+(obj1[obj1.length-1].lifemale)));
                    }

                    k[(parseFloat(check[4]))]=1;
                }
            }
        }
});

rd.on('close', function() {

    for(i=0;i<obj1.length;i++){

        obj1[i].lifemale = (obj1[i].lifemale / 40);
        obj1[i].lifefemale = (obj1[i].lifefemale / 40);
    }
var random=JSON.stringify(obj1);
fs.appendFile('question1.json',random);
});
