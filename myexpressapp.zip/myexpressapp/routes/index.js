var express = require('express');
var router = express.Router();
var _ = require('underscore');


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index.html', { title: "dsdsdsd" });
});
// var user = [{user_id:123, user_name:'anand', cmp_id:001}];
// var company = [{cmp_id:001, cmp_name:'abc', admin_id:200}];
// var admin = [{admin_id:200, admin_name:'xyz', plan_expire:'04-09-2018'}];

// router.get('/', function (req, res) {
//   res.header("Access-Control-Allow-Origin", "*");
//   res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
//   if(req.query.userid){
//         _.each(user,function(user){
//           if(user.user_id === parseInt(req.query.userid)){
//             _.each(company,function(company){
//               if(company.cmp_id === user.cmp_id){
//                 _.each(admin,function(admin){
//                   if(admin.admin_id === company.admin_id){
//                       res.send(req.query.userid).status(200);
//                   }
//                 });
//               }
//             });
//           }else{
//           	  res.send('entered userid is not present').status(200);
//           }
//         });


//   }else{
//       res.send('enter userid').status(200);
//    }
// })


module.exports = router;
